import React, { Component } from 'react';
import Counter from './Counter';


//rcc

export default class App extends Component {
  render() {
    return <div>
<Counter/>

    </div>;
  }
}

